
    <?php

    $db_user = "lkj";
    $db_pass = "hlk";
    $db_host = "jh";
    $db_name = "lkj";

    $admin_email = "jaja@gmail.com";

    <br />