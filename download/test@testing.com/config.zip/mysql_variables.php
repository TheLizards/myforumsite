
    <?php

    $db_user = "root";
    $db_pass = "1234";
    $db_host = "localhost";
    $db_name = "demo";

    $admin_email = "test@testing.com";

    <br />