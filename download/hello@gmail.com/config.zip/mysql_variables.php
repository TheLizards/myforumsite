
    <?php

    $db_user = "lkjhlk";
    $db_pass = "jh";
    $db_host = "lk";
    $db_name = "h";

    $admin_email = "hello@gmail.com";

    <br />