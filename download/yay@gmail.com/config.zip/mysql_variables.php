
    <?php

    $db_user = "k";
    $db_pass = "jh";
    $db_host = "kj";
    $db_name = "h";

    $admin_email = "yay@gmail.com";

    <br />